/*
 * Where it is all started, calling Menu classes show method
 * 
 */

package ie.gmit.sw;

public class Runner {
	public static void main(String[] args) throws Exception{		
		new Menu().show();
	}
}
